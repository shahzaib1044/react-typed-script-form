# This is the testing application, you should check out the [documentation](https://codestix.github.io/typed-react-form/) for examples.
